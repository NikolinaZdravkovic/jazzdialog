JazzDialog pilot manual annotations

Open reviewed_dataset.json. MIDI paths are relative to this archive root.
Each MIDI contains CALL and RESPONSE tracks. MIDI time starts at call onset;
JSON note times are seconds from the solo origin. MIDI rounding tolerance: 5 ms.
DA labels are human judgments. Overlapping versions are retained and flagged;
annotation_count is not a count of independent final examples.
Use evaluation_group to keep the same solo out of both training and test.

Source: Weimar Jazz Database, Jazzomat Research Project
https://jazzomat.hfm-weimar.de/
WJD source database: Open Data Commons Open Database License (ODbL).
https://opendatacommons.org/licenses/odbl/1-0/
Source database and review CSV are not bundled. source_csv/source_sha256
identify provenance in the project, not another required archive member.
Project: https://github.com/NikolinaZdravkovic/jazzdialog
